import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import React from 'react';
import './App.css';

/* =====Importing==== */
import Login from './pages/login';
import AdminDashboard from './admin/admin-dashboard';
import ManageStaff from './admin/manage-staff';
import ManageOwner from './admin/manage-owner';
import ManageLand from './admin/manage-land';
import StaffDashboard from './staff/staff-dashboard';
import LandRegistration from './staff/register-land';
import RegisteredLand from './staff/registered-land';
import LandOwner from './staff/land-owner';
import OwnerDashboard from './owner/owner-dashboard';
import LandList from './owner/land-list';
import RegisterStaff from './admin/registerStaff';
import UpdateStaff from './admin/updateStaff';
import RegisterOwner from './admin/registerOwner';
import UpdateOwner from './admin/updateOwner';
import { Auth } from './pages/auth';
import ChangePassword from './admin/changePassword';
import UpdateLand from './staff/updateLand';
import UpdateOwnerStaff from './staff/updateOwner';
import LandMap from './owner/landMap';



function App() {
  return (
    <Router>
      <Routes>

        {/* =====Admin Dashboard Start===== */}
        <Route path="/" element={<Login />} />
     
        {/* =====Admin Dashboard Start===== */}
        <Route path="/admin/admin-dashboard" element={<Auth><AdminDashboard /></Auth>} />
        <Route path="/admin/manage-staff" element={<Auth><ManageStaff /></Auth>} />
        <Route path="/admin/addStaff" element={<Auth><RegisterStaff /></Auth>} />  
        <Route path="/admin/editStaff/:id" element={<Auth><UpdateStaff /></Auth>} />  
        <Route path="/admin/manage-owner" element={<Auth><ManageOwner /></Auth>} />
        <Route path="/admin/addOwner" element={<Auth><RegisterOwner /></Auth>} />
        <Route path="/admin/editOwner/:id" element={<Auth><UpdateOwner /></Auth>} />
        <Route path="/admin/manage-land" element={<Auth><ManageLand /></Auth>} />
        <Route path="/admin/change-password" element={<Auth><ChangePassword /></Auth>} />
        
        {/* End of Admin Dashboard */}

        {/* =====Staff Dashboard Start===== */}
        <Route path="/staff/staff-dashboard" element={<Auth><StaffDashboard /></Auth>} />
        <Route path="/staff/register-land" element={<Auth><LandRegistration /></Auth>} />
        <Route path="/staff/registered-land" element={<Auth><RegisteredLand /></Auth>} />
        <Route path="/staff/editLand/:landId" element={<Auth><UpdateLand /></Auth>} />
        
        <Route path="/staff/land-owner" element={<Auth><LandOwner /></Auth>} />
        <Route path="/staff/editOwner/:id" element={<Auth><UpdateOwnerStaff /></Auth>} />
        {/* End of Staff Dashboard */}

        {/* =====Owner Dashboard Start===== */}
        <Route path="/owner/owner-dashboard" element={<Auth><OwnerDashboard /></Auth>} />
        <Route path="//owner/viewMap/:id" element={<Auth><LandMap /></Auth>} />
        <Route path="/owner/land-list" element={<Auth><LandList /></Auth>} />
        {/* End of Owner Dashboard */}

      </Routes>
    </Router>
  );
}

export default App;
