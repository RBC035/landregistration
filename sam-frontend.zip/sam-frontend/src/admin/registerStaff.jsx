import { useState } from "react";
import Header from "./header";
import Sidebar from "./sidebar";
import staffService from "../service/staffService";
import authService from "../service/authService";
import { useNavigate } from "react-router-dom";

const RegisterStaff = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const navigate = useNavigate();

  const [staffData, setStaffData] = useState({
    fullName: "",
    position: "",
    phone: "",
    email: "",
    status: "Active",
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStaffData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const userData = {
      username: staffData.email,
      password: "123",
      role: "Staff",
    };

    staffService
      .createStaff(staffData)
      .then((res) => {
        return authService.signup(userData);
      })
      .then((res) => {
        setMessage("Staff registered successfully!");
        setStaffData({
          fullName: "",
          position: "",
          phone: "",
          email: "",
          status: "Active",
        });
        setTimeout(() => navigate("/admin/manage-staff"), 1000);
      })
      .catch((err) => {
        console.error(err);
        setMessage("Error registering staff. Please try again.");
      });
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="row justify-content-center mt-5">
          <div className="col-md-6">
            <div className="card shadow w-100" style={{ maxWidth: "600px" }}>
              <div className="card-header">
                <h4 className="mt-2 text-center">Register Staff</h4>
              </div>
              <div className="card-body px-4 py-5">
                {message && <div className="alert alert-info">{message}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      name="fullName"
                      className="form-control"
                      value={staffData.fullName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Position</label>
                    <input
                      type="text"
                      name="position"
                      className="form-control"
                      value={staffData.position}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Phone</label>
                    <input
                      type="text"
                      name="phone"
                      className="form-control"
                      value={staffData.phone}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      value={staffData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3 d-none">
                    <label className="form-label">Status</label>
                    <select
                      name="status"
                      className="form-select"
                      value={staffData.status}
                      onChange={handleChange}
                    >
                      <option>Active</option>
                      <option>Inactive</option>
                      <option>Pending</option>
                    </select>
                  </div>

                  <button type="submit" className="btn btn-primary w-100">
                    Register Staff
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterStaff;
