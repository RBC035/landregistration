import React, { useState, useEffect } from "react";
import {
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import Sidebar from "./sidebar";
import Header from "./header";
import landService from "../service/landService";
import { useNavigate } from "react-router-dom";

const ManageLand = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [landData, setLandData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const navigate = useNavigate();

  // --- Fetch lands from backend ---
  useEffect(() => {
    landService
      .getAllLands()
      .then((res) => setLandData(res.data))
      .catch((err) => console.error("Error fetching lands:", err));
  }, []);

  const requestSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc")
      direction = "desc";
    setSortConfig({ key, direction });
  };

  const sortedData = [...landData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    if (a[sortConfig.key] < b[sortConfig.key])
      return sortConfig.direction === "asc" ? -1 : 1;
    if (a[sortConfig.key] > b[sortConfig.key])
      return sortConfig.direction === "asc" ? 1 : -1;
    return 0;
  });

  const filteredData = sortedData.filter(
    (land) =>
      (land.land_id?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
      (land.ward?.toLowerCase() || "").includes(searchTerm.toLowerCase()) ||
      (land.owner_id?.toLowerCase() || "").includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const currentData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <FaSort className="ms-1" />;
    return sortConfig.direction === "asc" ? (
      <FaSortUp className="ms-1" />
    ) : (
      <FaSortDown className="ms-1" />
    );
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid">
          <div className="mt-3 mb-4">
            <div className="row gy-2 align-items-center">
              <div className="col-12">
                <h4 className="text-gray-800">Manage Land</h4>
              </div>

              <div className="col-md-6 col-lg-2">
                <div className="input-group input-group-sm">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <span className="input-group-text">
                    <FaSearch />
                  </span>
                </div>
              </div>

              <div className="col-md-6 col-lg-4 ms-auto text-end">
                <button className="btn btn-sm btn-primary" onClick={()=> navigate("/admin/addLand")}>
                  <FaPlus className="me-2" /> Add Land
                </button>
              </div>
            </div>
          </div>

          <div className="card shadow">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-bordered">
                  <thead className="thead-light">
                    <tr>
                      <th
                        onClick={() => requestSort("land_id")}
                        style={{ cursor: "pointer" }}
                      >
                        Land ID {getSortIcon("land_id")}
                      </th>
                      <th
                        onClick={() => requestSort("register_by")}
                        style={{ cursor: "pointer" }}
                      >
                        Register By {getSortIcon("register_by")}
                      </th>
                      <th
                        onClick={() => requestSort("size")}
                        style={{ cursor: "pointer" }}
                      >
                        Size {getSortIcon("size")}
                      </th>
                      <th
                        onClick={() => requestSort("ward")}
                        style={{ cursor: "pointer" }}
                      >
                        Ward {getSortIcon("ward")}
                      </th>
                      <th
                        onClick={() => requestSort("land_use")}
                        style={{ cursor: "pointer" }}
                      >
                        Land Use {getSortIcon("land_use")}
                      </th>
                      <th
                        onClick={() => requestSort("register")}
                        style={{ cursor: "pointer" }}
                      >
                        Register Date {getSortIcon("register")}
                      </th>
                      <th
                        onClick={() => requestSort("district")}
                        style={{ cursor: "pointer" }}
                      >
                        District {getSortIcon("district")}
                      </th>
                      <th>GPS Coordinates</th>
                      <th
                        onClick={() => requestSort("region")}
                        style={{ cursor: "pointer" }}
                      >
                        Region {getSortIcon("region")}
                      </th>
                      <th
                        onClick={() => requestSort("owner_id")}
                        style={{ cursor: "pointer" }}
                      >
                        Owner ID {getSortIcon("owner_id")}
                      </th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentData.map((land) => (
                      <tr key={land.land_id}>
                        <td>{land.landId}</td>
                        <td>{land.registerBy}</td>
                        <td>{land.size}</td>
                        <td>{land.ward}</td>
                        <td>{land.landUse}</td>
                        <td>{land.registerDate}</td>
                        <td>{land.district}</td>
                        <td>{`${land.latitude}, ${land.longitude}`}</td>
                        <td>{land.region}</td>
                        <td>{land.ownerId}</td>
                        <td>
                          <button className="btn btn-sm btn-primary me-2">
                            <FaEdit />
                          </button>
                          <button className="btn btn-sm btn-danger">
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
                  {Math.min(currentPage * rowsPerPage, filteredData.length)} of{" "}
                  {filteredData.length} entries
                </div>
                <div className="d-flex align-items-center">
                  <span className="me-2">Rows per page:</span>
                  <select
                    className="form-select form-select-sm"
                    style={{ width: "70px" }}
                  >
                    <option>5</option>
                    <option>10</option>
                    <option>25</option>
                  </select>

                  <div className="btn-group ms-3">
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((prev) => prev - 1)}
                    >
                      Previous
                    </button>
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((prev) => prev + 1)}
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageLand;
