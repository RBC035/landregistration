import React, { useState, useEffect } from "react";
import {
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import Sidebar from "./sidebar";
import Header from "./header";
import ownerService from "../service/ownerService";
import { useNavigate } from "react-router-dom";

const ManageOwner = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [ownerData, setOwnerData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const navigate = useNavigate();

  // --- Fetch owners from backend ---
  const fetchOwners = () => {
    ownerService
      .getAllOwners()
      .then((res) => setOwnerData(res.data))
      .catch((err) => console.error("Error fetching owners:", err));
  };

  useEffect(() => {
    fetchOwners();
  }, []);

  const requestSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") direction = "desc";
    setSortConfig({ key, direction });
  };

  const sortedData = [...ownerData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === "asc" ? -1 : 1;
    if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === "asc" ? 1 : -1;
    return 0;
  });

  const filteredData = sortedData.filter(
    (owner) =>
      owner.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      owner.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const currentData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <FaSort className="ms-1" />;
    return sortConfig.direction === "asc" ? <FaSortUp className="ms-1" /> : <FaSortDown className="ms-1" />;
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this owner?")) {
      ownerService
        .deleteOwner(id)
        .then(() => fetchOwners())
        .catch((err) => console.error(err));
    }
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div id="content" className={`content ${!isSidebarOpen ? "full-width" : ""}`}>
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid">
          <div className="mt-3 mb-4">
            <div className="row gy-2 align-items-center">
              <div className="col-12">
                <h4 className="text-gray-800">Manage Owners</h4>
              </div>
              <div className="col-md-6 col-lg-2">
                <div className="input-group input-group-sm">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <span className="input-group-text"><FaSearch /></span>
                </div>
              </div>
              <div className="col-md-6 col-lg-4 ms-auto text-end">
                <button className="btn btn-sm btn-primary" onClick={() => navigate("/admin/addOwner")}>
                  <FaPlus className="me-2" /> Add Owner
                </button>
              </div>
            </div>
          </div>

          <div className="card shadow">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-bordered">
                  <thead className="thead-light">
                    <tr>
                      <th>#</th>
                      <th onClick={() => requestSort("zanID")} style={{ cursor: "pointer" }}>
                        Zan ID {getSortIcon("zanID")}
                      </th>
                      <th onClick={() => requestSort("fullName")} style={{ cursor: "pointer" }}>
                        Full Name {getSortIcon("fullName")}
                      </th>
                      <th onClick={() => requestSort("ownerType")} style={{ cursor: "pointer" }}>
                        Owner Type {getSortIcon("ownerType")}
                      </th>
                      <th>Phone No</th>
                      <th onClick={() => requestSort("address")} style={{ cursor: "pointer" }}>
                        Address {getSortIcon("address")}
                      </th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentData.map((owner, index) => (
                      <tr key={owner.id}>
                        <td>{(currentPage - 1) * rowsPerPage + index + 1}</td>
                        <td>{owner.zanID}</td>
                        <td>{owner.fullName}</td>
                        <td>{owner.ownerType}</td>
                        <td>{owner.phone}</td>
                        <td>{owner.address}</td>
                        <td>
                          <span className={`badge bg-${
                            owner.status === "Active" ? "success" :
                            owner.status === "Inactive" ? "danger" : "warning"
                          }`}>
                            {owner.status}
                          </span>
                        </td>
                        <td>
                          <button
                            className="btn btn-sm btn-primary me-2"
                            onClick={() => navigate(`/admin/editOwner/${owner.id}`)}
                          >
                            <FaEdit />
                          </button>
                          <button
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(owner.id)}
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {(currentPage - 1) * rowsPerPage + 1} to {Math.min(currentPage * rowsPerPage, filteredData.length)} of {filteredData.length} entries
                </div>
                <div className="d-flex align-items-center">
                  <span className="me-2">Rows per page:</span>
                  <select
                    className="form-select form-select-sm"
                    style={{ width: "70px" }}
                  >
                    <option>5</option>
                    <option>10</option>
                    <option>25</option>
                  </select>

                  <div className="btn-group ms-3">
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((prev) => prev - 1)}
                    >
                      Previous
                    </button>
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((prev) => prev + 1)}
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageOwner;
