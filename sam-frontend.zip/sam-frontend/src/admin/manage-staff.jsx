import React, { useState, useEffect } from "react";
import {
  FaSearch,
  FaPlus,
  FaEdit,
  FaTrash,
  FaSort,
  FaSortUp,
  FaSortDown,
} from "react-icons/fa";
import Sidebar from "./sidebar";
import Header from "./header";
import staffService from "../service/staffService";
import { useNavigate } from "react-router-dom";

const ManageStaff = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [staffData, setStaffData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });
  const navigate = useNavigate();

  // Fetch staff data
  const fetchStaff = () => {
    staffService
      .getAllStaff()
      .then((res) => setStaffData(res.data))
      .catch((err) => console.error("Error fetching staff:", err));
  };

  useEffect(() => {
    fetchStaff();
  }, []);

  const requestSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc")
      direction = "desc";
    setSortConfig({ key, direction });
  };

  const sortedData = [...staffData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    if (a[sortConfig.key] < b[sortConfig.key])
      return sortConfig.direction === "asc" ? -1 : 1;
    if (a[sortConfig.key] > b[sortConfig.key])
      return sortConfig.direction === "asc" ? 1 : -1;
    return 0;
  });

  const filteredData = sortedData.filter(
    (staff) =>
      staff.fullName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      staff.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const currentData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <FaSort className="ms-1" />;
    return sortConfig.direction === "asc" ? (
      <FaSortUp className="ms-1" />
    ) : (
      <FaSortDown className="ms-1" />
    );
  };

  // Handle delete
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this staff?")) {
      staffService
        .deleteStaff(id)
        .then(() => fetchStaff())
        .catch((err) => console.error("Delete failed:", err));
    }
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid">
          <div className="mt-3 mb-4">
            <div className="row gy-2 align-items-center">
              <div className="col-12">
                <h4 className="text-gray-800">Manage Staff</h4>
              </div>

              <div className="col-md-6 col-lg-2">
                <div className="input-group input-group-sm">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <span className="input-group-text">
                    <FaSearch />
                  </span>
                </div>
              </div>

              <div className="col-md-6 col-lg-4 ms-auto text-end">
                <button
                  className="btn btn-sm btn-primary"
                  onClick={() => navigate("/admin/addStaff")}
                >
                  <FaPlus className="me-2" /> Add Staff
                </button>
              </div>
            </div>
          </div>

          <div className="card shadow">
            <div className="card-body mt-3">
              <div className="table-responsive">
                <table className="table table-bordered">
                  <thead className="thead-light">
                    <tr>
                      <th
                        onClick={() => requestSort("id")}
                        style={{ cursor: "pointer" }}
                      >
                        ID {getSortIcon("id")}
                      </th>
                      <th
                        onClick={() => requestSort("fullName")}
                        style={{ cursor: "pointer" }}
                      >
                        Full Name {getSortIcon("fullName")}
                      </th>
                      <th
                        onClick={() => requestSort("position")}
                        style={{ cursor: "pointer" }}
                      >
                        Position {getSortIcon("position")}
                      </th>
                      <th>Phone No</th>
                      <th
                        onClick={() => requestSort("email")}
                        style={{ cursor: "pointer" }}
                      >
                        Email {getSortIcon("email")}
                      </th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentData.map((staff, index) => (
                      <tr key={staff.id}>
                        <td>{(currentPage - 1) * rowsPerPage + index + 1}</td>
                        <td>{staff.fullName}</td>
                        <td>{staff.position}</td>
                        <td>{staff.phone}</td>
                        <td>{staff.email}</td>
                        <td>
                          <span
                            className={`badge bg-${
                              staff.status === "Active"
                                ? "success"
                                : staff.status === "Inactive"
                                ? "danger"
                                : "warning"
                            }`}
                          >
                            {staff.status}
                          </span>
                        </td>
                        <td>
                          <button
                            className="btn btn-sm btn-primary me-2"
                            onClick={() =>
                              navigate(`/admin/editStaff/${staff.id}`)
                            }
                          >
                            <FaEdit />
                          </button>
                          <button
                            className="btn btn-sm btn-danger"
                            onClick={() => handleDelete(staff.id)}
                          >
                            <FaTrash />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {(currentPage - 1) * rowsPerPage + 1} to{" "}
                  {Math.min(currentPage * rowsPerPage, filteredData.length)} of{" "}
                  {filteredData.length} entries
                </div>
                <div className="d-flex align-items-center">
                  <span className="me-2">Rows per page:</span>
                  <select
                    className="form-select form-select-sm"
                    style={{ width: "70px" }}
                  >
                    <option>5</option>
                    <option>10</option>
                    <option>25</option>
                  </select>

                  <div className="btn-group ms-3">
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((prev) => prev - 1)}
                    >
                      Previous
                    </button>
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((prev) => prev + 1)}
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageStaff;
