const RegisterLand = () => {
  return (
    <div>registerLand</div>
  )
}

export default RegisterLand