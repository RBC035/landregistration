import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "./sidebar";
import Header from "./header";
import { jwtDecode } from "jwt-decode";
import authService from "../service/authService";

const ChangePassword = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [formData, setFormData] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.newPassword !== formData.confirmPassword) {
      setMessage("New password and confirm password do not match");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Not authenticated");

      const decoded = jwtDecode(token);
      const userId = decoded.userId || decoded.id;

      await authService.changePassword(userId, {
        oldPassword: formData.oldPassword,
        newPassword: formData.newPassword,
      });

      setMessage("Password changed successfully!");
      setTimeout(() => navigate("/admin/admin-dashboard"), 1500);
    } catch (error) {
      console.error(error);
      setMessage("Error changing password. Please check your old password.");
    }
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="row justify-content-center mt-5">
          <div className="col-md-6">
            <div className="card shadow w-100" style={{ maxWidth: "600px" }}>
              <div className="card-header">
                <h4 className="mt-2 text-center">Change Password</h4>
              </div>
              <div className="card-body px-4 py-5">
                {message && <div className="alert alert-info">{message}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="mb-3">
                    <label className="form-label">Old Password</label>
                    <input
                      type="password"
                      name="oldPassword"
                      className="form-control"
                      value={formData.oldPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">New Password</label>
                    <input
                      type="password"
                      name="newPassword"
                      className="form-control"
                      value={formData.newPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Confirm New Password</label>
                    <input
                      type="password"
                      name="confirmPassword"
                      className="form-control"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <button type="submit" className="btn btn-primary w-100">
                    Change password
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangePassword;
