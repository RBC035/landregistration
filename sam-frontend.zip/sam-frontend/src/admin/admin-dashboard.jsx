import React, { useState } from 'react';
import Sidebar from './sidebar';
import Header from './header';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import '../assets/css/style.css';
import '../assets/css/dashboard.css';

const AdminDashboard = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
  
    const toggleSidebar = () => {
      setSidebarOpen(!isSidebarOpen);
    };
  
    return (
      <div className="wrapper">
        <Sidebar isOpen={isSidebarOpen} />
        <div id="content" className={`content ${!isSidebarOpen ? 'full-width' : ''}`}>
          <Header toggleSidebar={toggleSidebar} />
          <div className="container-fluid">
            <div className="row mb-4">
              <div className="col-12">
              <h2>Dashboard Overview</h2>
              <p>Welcome back, Admin!</p>
            </div>
          </div>
          <div className="row">
            <div className="col-xl-3 col-md-6 mb-4">
              <div className="card border-left-primary shadow h-100 py-2">
                <div className="card-body">
                  <div className="row no-gutters align-items-center">
                    <div className="col mr-2">
                      <div className="text-xs font-weight-bold text-primary text-uppercase mb-1">
                        Total Staffs
                      </div>
                      <div className="h5 mb-0 font-weight-bold text-gray-800">13</div>
                    </div>
                    <div className="col-auto">
                      <i className="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xl-3 col-md-6 mb-4">
              <div className="card border-left-success shadow h-100 py-2">
                <div className="card-body">
                  <div className="row no-gutters align-items-center">
                    <div className="col mr-2">
                      <div className="text-xs font-weight-bold text-success text-uppercase mb-1">
                        Registered Land
                      </div>
                      <div className="h5 mb-0 font-weight-bold text-gray-800">178</div>
                    </div>
                    <div className="col-auto">
                      <i className="fas fa-map-marked-alt fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xl-3 col-md-6 mb-4">
              <div className="card border-left-info shadow h-100 py-2">
                <div className="card-body">
                  <div className="row no-gutters align-items-center">
                    <div className="col mr-2">
                      <div className="text-xs font-weight-bold text-info text-uppercase mb-1">
                        Land Owners
                      </div>
                      <div className="h5 mb-0 font-weight-bold text-gray-800">102</div>
                    </div>
                    <div className="col-auto">
                      <i className="fas fa-user-tie fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xl-3 col-md-6 mb-4">
              <div className="card border-left-warning shadow h-100 py-2">
                <div className="card-body">
                  <div className="row no-gutters align-items-center">
                    <div className="col mr-2">
                      <div className="text-xs font-weight-bold text-warning text-uppercase mb-1">
                        Certificate Printed
                      </div>
                      <div className="h5 mb-0 font-weight-bold text-gray-800">58</div>
                    </div>
                    <div className="col-auto">
                      <i className="fas fa-print fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
