import React, { useEffect, useState } from 'react';
import { FaMapMarkerAlt } from 'react-icons/fa';
import Sidebar from './sidebar';
import Header from './header';
import { jwtDecode } from 'jwt-decode';
import landService from '../service/landService';
import { useNavigate } from 'react-router-dom';

const LandList = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [lands, setLands] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    const decodedToken = jwtDecode(token);
    const zanId = decodedToken.sub;

    landService.getLandsByOwnerId(zanId)
      .then((res) => setLands(res.data))
      .catch((e) => console.error("Error fetching lands:", e))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div id="content" className={`content ${!isSidebarOpen ? 'full-width' : ''}`}>
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid mt-4">
          <h4 className="mb-3 text-gray-800">My Land List</h4>
          <div className="card shadow">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-bordered table-hover">
                  <thead className="thead-light">
                    <tr>
                      <th>#</th>
                      <th>Region</th>
                      <th>District</th>
                      <th>Shehia</th>
                      <th>Heka</th>
                      {/* <th>Owner Type</th> */}
                      <th>View Location</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lands.map((land, index) => (
                      <tr key={land.landId}>
                        <td>{index + 1}</td>
                        <td>{land.region}</td>
                        <td>{land.district}</td>
                        <td>{land.shehia}</td>
                        <td>{land.landUse}</td>
                        {/* <td>{land.ownerType}</td> */}
                        <td className="text-center">
                          <button className="btn btn-sm btn-outline-info" title="View on Map" onClick={() => navigate(`/owner/viewMap/${land.landId}`)}>
                            <FaMapMarkerAlt />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {lands.length === 0 && <p className="text-center mt-2">No lands found.</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandList;
