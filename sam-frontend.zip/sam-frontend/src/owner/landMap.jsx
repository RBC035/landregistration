import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import Sidebar from "./sidebar";
import Header from "./header";
import landService from "../service/landService";

const LandMap = () => {
  const { id } = useParams(); // landId from route
  const [land, setLand] = useState(null);
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    landService
      .getLandById(id)
      .then((res) => {
        setLand(res.data);
      })
      .catch((err) => {
        console.error("Error fetching land:", err);
      });
  }, [id]);

  if (!land) return <div>Loading map...</div>;

  // Default map center if no lat/long
  const position =
    land.latitude && land.longitude
      ? [land.latitude, land.longitude]
      : [-6.1659, 39.2026]; // fallback: Zanzibar coords

  return (
    <div className="wrapper">
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} />

      <div id="content" className={`content ${!isSidebarOpen ? "full-width" : ""}`}>
        {/* Header */}
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid mt-4">
          <h4 className="mb-3 text-gray-800">Land Location - {land.landId}</h4>

          <div className="card shadow">
  <div className="card-body">
    {/* Map wrapper to enforce size and boundaries */}
    <div style={{ height: "500px", width: "100%", overflow: "hidden", borderRadius: "8px" }}>
      <MapContainer
        center={position}
        zoom={12}
        style={{ height: "100%", width: "100%" }}
        maxBounds={[
          [-6.5, 39.0], // SW
          [-5.5, 39.6], // NE
        ]}
        maxBoundsViscosity={1.0}
      >
        <TileLayer
          attribution='&copy; <a href="https://osm.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {land.latitude && land.longitude && (
          <Marker position={[land.latitude, land.longitude]}>
            <Popup>
              <strong>Owner:</strong> {land.ownerId} <br />
              <strong>Shehia:</strong> {land.shehia} <br />
              <strong>District:</strong> {land.district}
            </Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  </div>
</div>


        </div>
      </div>
    </div>
  );
};

export default LandMap;
