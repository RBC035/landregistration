import axios from "axios";

const API_URL = "http://localhost:8080/staffs";

class StaffService {
  // --- Get all staff ---
  getAllStaff() {
    return axios.get(API_URL);
  }

  // --- Get staff by ID ---
  getStaffById(id) {
    return axios.get(`${API_URL}/${id}`);
  }

  // --- Get staff by email ---
  getStaffByEmail(email) {
    return axios.get(`${API_URL}/email/${email}`);
  }

  // --- Create a new staff ---
  createStaff(staffData) {
    return axios.post(API_URL, staffData);
  }

  // --- Update staff by ID ---
  updateStaff(id, staffData) {
    return axios.put(`${API_URL}/${id}`, staffData);
  }

  // --- Delete staff by ID ---
  deleteStaff(id) {
    return axios.delete(`${API_URL}/${id}`);
  }
}

export default new StaffService();
