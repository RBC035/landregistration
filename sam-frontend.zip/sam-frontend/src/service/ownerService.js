import axios from "axios";

const API_URL = "http://localhost:8080/owners";

class OwnerService {
  // --- Get all owners ---
  getAllOwners() {
    return axios.get(API_URL);
  }

  // --- Get owner by ID ---
  getOwnerById(id) {
    return axios.get(`${API_URL}/${id}`);
  }

  // --- Get owner by ZanID ---
  getOwnerByZanID(zanID) {
    return axios.get(`${API_URL}/zanid/${zanID}`);
  }

  // --- Create a new owner ---
  createOwner(ownerData) {
    return axios.post(API_URL, ownerData);
  }

  // --- Update owner by ID ---
  updateOwner(id, ownerData) {
    return axios.put(`${API_URL}/${id}`, ownerData);
  }

  // --- Delete owner by ID ---
  deleteOwner(id) {
    return axios.delete(`${API_URL}/${id}`);
  }
}

export default new OwnerService();
