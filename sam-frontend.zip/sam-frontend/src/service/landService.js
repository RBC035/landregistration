import axios from "axios";

const API_URL = "http://localhost:8080/lands";

class LandService {
  // --- Get all lands ---
  getAllLands() {
    return axios.get(API_URL);
  }

  // --- Get land by ID ---
  getLandById(landId) {
    return axios.get(`${API_URL}/${landId}`);
  }

  // --- Get lands by owner ID ---
  getLandsByOwnerId(ownerId) {
    return axios.get(`${API_URL}/owner/${ownerId}`);
  }

  // --- Create a new land ---
  createLand(landData) {
    return axios.post(API_URL, landData);
  }

  // --- Update land by ID ---
  updateLand(landId, landData) {
    return axios.put(`${API_URL}/${landId}`, landData);
  }

  // --- Delete land by ID ---
  deleteLand(landId) {
    return axios.delete(`${API_URL}/${landId}`);
  }
}

export default new LandService();
