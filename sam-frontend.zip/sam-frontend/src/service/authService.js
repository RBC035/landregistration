import axios from "axios";

const API_URL = "http://localhost:8080/auth";

class AuthService {
  // --- Register new user ---
  signup(userData) {
    return axios.post(`${API_URL}/signup`, userData);
  }

  // --- Login user ---
  login(credentials) {
    return axios.post(`${API_URL}/login`, credentials);
  }

  // --- Fetch all users ---
  getAllUsers() {
    return axios.get(`${API_URL}`);
  }

  // --- Get user by username ---
  getUserByUsername(username) {
    return axios.get(`${API_URL}/byUsername`, {
      params: { username },
    });
  }

  // --- Get total count of users ---
  getUserCount() {
    return axios.get(`${API_URL}/count`);
  }

  // --- Change user password ---
  changePassword(userId, updatedUser) {
    return axios.put(`${API_URL}/${userId}`, updatedUser);
  }
}

export default new AuthService();
