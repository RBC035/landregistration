import React from 'react';
import { Navigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';

const isTokenExpired = (token) => {
    if (!token) return true; 
    
    const decoded = jwtDecode(token);
    const currentTime = Date.now() / 1000;  // Current time in seconds
    
    return decoded.exp < currentTime;
  };

  export const Auth = ({ children }) => {
    const token = localStorage.getItem("token");
  
    if (!token || isTokenExpired(token)) {
    
      alert("Session expired or no token found. Please login again.");
      return <Navigate to="/" />; 
    }
  
    return children;
  };