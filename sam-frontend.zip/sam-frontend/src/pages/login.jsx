import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "../assets/css/login.css";
import { jwtDecode } from "jwt-decode";

import AuthService from "../service/authService";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!username.trim() || !password.trim()) {
      setError("Username and password are required");
      return;
    }

    try {
      // Call backend login
      const response = await AuthService.login({ username, password });
      const { token } = response.data;

      // Save token locally
      localStorage.setItem("token", token);

      // Decode token to get role
      const decoded = jwtDecode(token);
      const role = decoded.role;

      // Navigate based on role
      switch (role) {
        case "ROLE_ADMIN":
          navigate("/admin/admin-dashboard");
          break;
        case "ROLE_STAFF":
          navigate("/staff/staff-dashboard");
          break;
        case "ROLE_OWNER":
          navigate("/owner/owner-dashboard");
          break;
        default:
          setError("Unknown user role");
      }
    } catch (err) {
      console.error("Login failed:", err);
      setError("Invalid username or password. Please try again.");
    }
  };

  return (
    <div
      className="container d-flex align-items-center"
      style={{ height: "100vh", backgroundColor: "#f8f9fc" }}
    >
      <div className="card login-card mx-auto">
        <div className="card-body p-5">
          <div className="logo-area text-center mb-4">
            <img src="images/location.png" alt="Logo" className="logo mb-3" />
            <h4 className="mb-2">Welcome back!</h4>
            <p className="text-muted">Sign in to your account to continue</p>
          </div>

          <form onSubmit={handleLogin}>
            {error && <p className="text-danger text-center">{error}</p>}
            <div className="mb-3">
              <label htmlFor="username" className="form-label">
                Username
              </label>
              <input
                type="text"
                className="form-control"
                id="username"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className="form-control"
                id="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="d-flex justify-content-between mb-4">
              <div className="form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="remember"
                />
                <label className="form-check-label" htmlFor="remember">
                  Remember me
                </label>
              </div>
              <a href="#" className="text-decoration-none text-primary">
                Forgot password?
              </a>
            </div>
            <button type="submit" className="btn btn-primary w-100 btn-login">
              Sign in
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
