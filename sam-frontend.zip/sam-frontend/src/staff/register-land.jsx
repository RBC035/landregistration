import React, { useState } from "react";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import Sidebar from "./sidebar";
import Header from "./header";

const LandRegistration = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    address: "",
    email: "",
    zanID: "",
    latitude: "",
    longitude: "",
    size: "",
    shape: "",
    region: "",
    ward: "",
    shehia: "",
    district: "",
    landUse: "",
  });

  const [errors, setErrors] = useState({});

  const ownerId = `OWN-${Math.random()
    .toString(36)
    .substr(2, 8)
    .toUpperCase()}`;
  const landId = `LAND-${Math.random()
    .toString(36)
    .substr(2, 8)
    .toUpperCase()}`;

  const validateStep = () => {
    const newErrors = {};
    if (step === 1) {
      if (!formData.size) newErrors.size = "Size is required";
      if (!formData.ward) newErrors.ward = "Ward is required";
    }
    if (step === 2) {
      if (!formData.fullName) newErrors.fullName = "Full name is required";
      if (!formData.phone) newErrors.phone = "Phone is required";
      if (!formData.email) newErrors.email = "Email is required";
      if (!formData.address) newErrors.address = "Address is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      setStep(step + 1);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep()) {
      const submissionData = {
        ...formData,
        ownerId,
        landId,
      };
      console.log("Submitting:", submissionData);
    }
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />
        <div className="container-fluid">
          <div className="mt-3 mb-4">
            <h4 className="text-gray-800">Land Registration Form</h4>
          </div>

          {/* Step Indicators */}
          <div className="d-flex justify-content-between mb-4">
            {[1, 2].map((i) => (
              <div key={i} className={`step ${step >= i ? "active" : ""}`}>
                <div className="step-circle">{i}</div>
                <div className="step-label">
                  {i === 1 && "Land Info"}
                  {i === 2 && "Owner Info"}
                </div>
              </div>
            ))}
          </div>

          {/* Form Card */}
          <div className="card shadow mb-4">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                {/* Step 1 - Land Info */}
                {step === 1 && (
                  <>
                    <div className="mb-4">
                      <h5>Land Information</h5>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">
                          Size (acres)*
                        </label>
                        <input
                          type="number"
                          className={`form-control form-control-sm ${
                            errors.size && "is-invalid"
                          }`}
                          value={formData.size}
                          onChange={(e) =>
                            setFormData({ ...formData, size: e.target.value })
                          }
                        />
                        {errors.size && (
                          <div className="invalid-feedback">{errors.size}</div>
                        )}
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Shape</label>
                        <select
                          className="form-control form-control-sm"
                          value={formData.shape}
                          onChange={(e) =>
                            setFormData({ ...formData, shape: e.target.value })
                          }
                        >
                          <option value="">Select shape</option>
                          <option value="Rectangular">Rectangular</option>
                          <option value="Square">Square</option>
                          <option value="Irregular">Irregular</option>
                        </select>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Latitude</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.latitude}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              latitude: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Longitude</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.longitude}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              longitude: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Region</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.region}
                          onChange={(e) =>
                            setFormData({ ...formData, region: e.target.value })
                          }
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">District</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.district}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              district: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Ward*</label>
                        <input
                          type="text"
                          className={`form-control form-control-sm ${
                            errors.ward && "is-invalid"
                          }`}
                          value={formData.ward}
                          onChange={(e) =>
                            setFormData({ ...formData, ward: e.target.value })
                          }
                        />
                        {errors.ward && (
                          <div className="invalid-feedback">{errors.ward}</div>
                        )}
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Shehia</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.shehia}
                          onChange={(e) =>
                            setFormData({ ...formData, shehia: e.target.value })
                          }
                        />
                      </div>
                    </div>

                    <div className="mb-3">
                      <label className="form-label small">Land Use</label>
                      <select
                        className="form-control form-control-sm"
                        value={formData.landUse}
                        onChange={(e) =>
                          setFormData({ ...formData, landUse: e.target.value })
                        }
                      >
                        <option value="">Select land use</option>
                        <option value="Residential">Residential</option>
                        <option value="Commercial">Commercial</option>
                        <option value="Agricultural">Agricultural</option>
                      </select>
                    </div>
                  </>
                )}

                {/* Step 2 - Owner Info */}
                {step === 2 && (
                  <>
                    <div className="mb-4">
                      <h5>Owner Information</h5>
                    </div>

                    <div className="mb-3">
                      <label className="form-label small">Full Name*</label>
                      <input
                        type="text"
                        className={`form-control form-control-sm ${
                          errors.fullName && "is-invalid"
                        }`}
                        value={formData.fullName}
                        onChange={(e) =>
                          setFormData({ ...formData, fullName: e.target.value })
                        }
                      />
                      {errors.fullName && (
                        <div className="invalid-feedback">
                          {errors.fullName}
                        </div>
                      )}
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">
                          Phone Number*
                        </label>
                        <input
                          type="tel"
                          className={`form-control form-control-sm ${
                            errors.phone && "is-invalid"
                          }`}
                          value={formData.phone}
                          onChange={(e) =>
                            setFormData({ ...formData, phone: e.target.value })
                          }
                        />
                        {errors.phone && (
                          <div className="invalid-feedback">{errors.phone}</div>
                        )}
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Email*</label>
                        <input
                          type="email"
                          className={`form-control form-control-sm ${
                            errors.email && "is-invalid"
                          }`}
                          value={formData.email}
                          onChange={(e) =>
                            setFormData({ ...formData, email: e.target.value })
                          }
                        />
                        {errors.email && (
                          <div className="invalid-feedback">{errors.email}</div>
                        )}
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Address*</label>
                        <input
                          type="text"
                          className={`form-control form-control-sm ${
                            errors.address && "is-invalid"
                          }`}
                          value={formData.address}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              address: e.target.value,
                            })
                          }
                        />
                        {errors.address && (
                          <div className="invalid-feedback">
                            {errors.address}
                          </div>
                        )}
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label small">Zan ID</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={formData.zanID}
                          onChange={(e) =>
                            setFormData({ ...formData, zanID: e.target.value })
                          }
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Navigation Buttons */}
                <div className="d-flex justify-content-between mt-4">
                  {step > 1 && (
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => setStep(step - 1)}
                    >
                      <FaArrowLeft className="me-2" /> Previous
                    </button>
                  )}
                  {step < 2 ? (
                    <button
                      type="button"
                      className="btn btn-primary ms-auto"
                      onClick={handleNext}
                    >
                      Next <FaArrowRight className="ms-2" />
                    </button>
                  ) : (
                    <button type="submit" className="btn btn-success ms-auto">
                      Complete Registration
                    </button>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandRegistration;
