import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Sidebar from "./sidebar";
import Header from "./header";
import landService from "../service/landService";

const UpdateLand = () => {
  const { landId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  const [land, setLand] = useState({
    region: "",
    district: "",
    ward: "",
    shehia: "",
    size: "",
    landUse: "",
    ownerId: "",
    registerBy: "",
    registerDate: "",
  });

  useEffect(() => {
    landService
      .getLandById(landId)
      .then((res) => setLand(res.data))
      .catch((err) => console.error(err));
  }, [landId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLand((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    landService
      .updateLand(landId, land)
      .then(() => navigate("/staff/registered-land"))
      .catch((err) => console.error(err));
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div id="content" className={`content ${!isSidebarOpen ? "full-width" : "600px"}`}>
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="container-fluid d-flex justify-content-center mt-5">
          <div className="col-md-5">
            <div className="card shadow">
              <div className="card-header">
                <h4 className="text-center mt-2">Edit Land</h4>
              </div>
              <div className="card-body pb-5 px-4">
                <form onSubmit={handleSubmit}>
                  <div className="mb-2">
                    <label>Region</label>
                    <input
                      type="text"
                      className="form-control"
                      name="region"
                      value={land.region}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>District</label>
                    <input
                      type="text"
                      className="form-control"
                      name="district"
                      value={land.district}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>Ward</label>
                    <input
                      type="text"
                      className="form-control"
                      name="ward"
                      value={land.ward}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>Shehia</label>
                    <input
                      type="text"
                      className="form-control"
                      name="shehia"
                      value={land.shehia}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>Size</label>
                    <input
                      type="text"
                      className="form-control"
                      name="size"
                      value={land.size}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>Land Use</label>
                    <input
                      type="text"
                      className="form-control"
                      name="landUse"
                      value={land.landUse}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="mb-2">
                    <label>Owner ID</label>
                    <input
                      type="text"
                      className="form-control"
                      name="ownerId"
                      value={land.ownerId}
                      onChange={handleChange}
                    />
                  </div>
                  <button className="btn btn-primary mt-2 w-100" type="submit">
                    Update
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateLand;
