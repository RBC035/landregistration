import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Header = ({ toggleSidebar }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <button type="button" id="sidebarCollapse" className="btn btn-info" onClick={toggleSidebar}>
          <i className="fas fa-align-left"></i>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown">
                <i className="fas fa-bell"></i>
                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  4
                </span>
              </a>
              <ul className="dropdown-menu dropdown-menu-end shadow" aria-labelledby="notificationsDropdown">
                <li><h6 className="dropdown-header">New Messages (4)</h6></li>
                <li>
                  <a className="dropdown-item" href="#">
                    <div className="d-flex align-items-center">
                      <i className="fas fa-envelope text-primary me-3"></i>
                      <div>
                        <div className="fw-bold">Message 1</div>
                        <small className="text-muted">3 mins ago</small>
                      </div>
                    </div>
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    <div className="d-flex align-items-center">
                      <i className="fas fa-envelope text-primary me-3"></i>
                      <div>
                        <div className="fw-bold">Message 2</div>
                        <small className="text-muted">1 hour ago</small>
                      </div>
                    </div>
                  </a>
                </li>
                <li><hr className="dropdown-divider" /></li>
                <li><a className="dropdown-item text-center text-primary" href="#">View all messages</a></li>
              </ul>
            </li>

            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                <i className="fas fa-user-circle me-1"></i> Staff User
              </a>
              <ul className="dropdown-menu dropdown-menu-end shadow">
              <Link className="dropdown-item" to="/staff/myProfile">
                    <i className="fas fa-user me-2"></i> My Profile
                  </Link>
                <li><hr className="dropdown-divider" /></li>
                <Link className="dropdown-item" to="/staff/change-password">
                    <i className="fas fa-cog me-2"></i> Change password
                  </Link>
                <li><hr className="dropdown-divider" /></li>
                <li>
                  <button
                    className="dropdown-item text-danger"
                    onClick={handleLogout}
                  >
                    <i className="fas fa-sign-out-alt me-2"></i> Log out
                  </button>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
