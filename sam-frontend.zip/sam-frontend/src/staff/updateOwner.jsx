import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Sidebar from "./sidebar";
import Header from "./header";
import ownerService from "../service/ownerService";

const UpdateOwnerStaff = () => {
  const { id } = useParams();
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const navigate = useNavigate();

  const [ownerData, setOwnerData] = useState({
    zanID: "",
    fullName: "",
    ownerType: "",
    phone: "",
    address: "",
    status: "Active",
  });

  const [message, setMessage] = useState("");

  // --- Fetch owner by ID ---
  useEffect(() => {
    ownerService
      .getOwnerById(id)
      .then((res) => setOwnerData(res.data))
      .catch((err) => console.error("Error fetching owner:", err));
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setOwnerData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    ownerService
      .updateOwner(id, ownerData)
      .then((res) => {
        setMessage("Owner updated successfully!");
        setTimeout(() => navigate("/staff/land-owner"), 1000);
      })
      .catch((err) => {
        console.error(err);
        setMessage("Error updating owner. Please try again.");
      });
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div
        id="content"
        className={`content ${!isSidebarOpen ? "full-width" : ""}`}
      >
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />

        <div className="row justify-content-center mt-5">
          <div className="col-md-6">
            <div className="card shadow w-100" style={{ maxWidth: "600px" }}>
              <div className="card-header">
                <h4 className="mt-2 text-center">CHange owner</h4>
              </div>
              <div className="card-body px-4 py-5">
                {message && <div className="alert alert-info">{message}</div>}

                <form onSubmit={handleSubmit}>
                  <div className="mb-3 d-none">
                    <label className="form-label">Zan ID</label>
                    <input
                      type="text"
                      name="zanID"
                      className="form-control"
                      value={ownerData.zanID}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      name="fullName"
                      className="form-control"
                      value={ownerData.fullName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Owner Type</label>
                    <input
                      type="text"
                      name="ownerType"
                      className="form-control"
                      value={ownerData.ownerType}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Phone</label>
                    <input
                      type="text"
                      name="phone"
                      className="form-control"
                      value={ownerData.phone}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Address</label>
                    <input
                      type="text"
                      name="address"
                      className="form-control"
                      value={ownerData.address}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Status</label>
                    <select
                      name="status"
                      className="form-select"
                      value={ownerData.status}
                      onChange={handleChange}
                    >
                      <option>Active</option>
                      <option>Inactive</option>
                      <option>Pending</option>
                    </select>
                  </div>

                  <button type="submit" className="btn btn-primary w-100">
                    Change owner
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateOwnerStaff;
