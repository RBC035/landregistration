import React, { useEffect, useState } from 'react';
import { FaSearch, FaSort, FaSortUp, FaSortDown, FaEdit } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import Sidebar from './sidebar';
import Header from './header';
import LandService from '../service/landService';

const RegisteredLand = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);
  const [landData, setLandData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  const navigate = useNavigate();

  // --- Fetch land data from backend ---
  useEffect(() => {
    LandService.getAllLands()
      .then(res => setLandData(res.data))
      .catch(err => console.error("Error fetching lands:", err));
  }, []);

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    setSortConfig({ key, direction });
  };

  const sortedData = [...landData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    return sortConfig.direction === 'asc'
      ? (a[sortConfig.key] > b[sortConfig.key] ? 1 : -1)
      : (a[sortConfig.key] < b[sortConfig.key] ? 1 : -1);
  });

  const filteredData = sortedData.filter((land) =>
    Object.values(land).some(value =>
      value && value.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const currentData = filteredData.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <FaSort className="ms-1" />;
    return sortConfig.direction === 'asc'
      ? <FaSortUp className="ms-1" />
      : <FaSortDown className="ms-1" />;
  };

  return (
    <div className="wrapper">
      <Sidebar isOpen={isSidebarOpen} />
      <div id="content" className={`content ${!isSidebarOpen ? 'full-width' : ''}`}>
        <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />
        <div className="container-fluid mt-3">
          <h4 className="text-gray-800 mb-3">Registered Land</h4>

          <div className="row mb-3">
            <div className="col-md-4">
              <div className="input-group input-group-sm">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="card shadow">
            <div className="card-body table-responsive">
              <table className="table table-bordered">
                <thead className="thead-light">
                  <tr>
                    <th onClick={() => requestSort('landId')} style={{ cursor: 'pointer' }}>Land ID {getSortIcon('landId')}</th>
                    <th onClick={() => requestSort('region')} style={{ cursor: 'pointer' }}>Region {getSortIcon('region')}</th>
                    <th onClick={() => requestSort('district')} style={{ cursor: 'pointer' }}>District {getSortIcon('district')}</th>
                    <th onClick={() => requestSort('ward')} style={{ cursor: 'pointer' }}>Ward {getSortIcon('ward')}</th>
                    <th onClick={() => requestSort('shehia')} style={{ cursor: 'pointer' }}>Shehia {getSortIcon('shehia')}</th>
                    <th>GPS</th>
                    <th onClick={() => requestSort('size')} style={{ cursor: 'pointer' }}>Size {getSortIcon('size')}</th>
                    <th onClick={() => requestSort('landUse')} style={{ cursor: 'pointer' }}>Land Use {getSortIcon('landUse')}</th>
                    <th>Owner ID</th>
                    <th>Registered By</th>
                    <th>Registered Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentData.map((land, index) => (
                    <tr key={index}>
                      <td>{land.landId}</td>
                      <td>{land.region}</td>
                      <td>{land.district}</td>
                      <td>{land.ward}</td>
                      <td>{land.shehia}</td>
                      <td>{land.latitude && land.longitude ? `${land.latitude}, ${land.longitude}` : ''}</td>
                      <td>{land.size}</td>
                      <td>{land.landUse}</td>
                      <td>{land.ownerId}</td>
                      <td>{land.registerBy}</td>
                      <td>{land.registerDate}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={() => navigate(`/staff/editLand/${land.landId}`)}
                        >
                          <FaEdit />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Pagination */}
              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {((currentPage - 1) * rowsPerPage) + 1} to{' '}
                  {Math.min(currentPage * rowsPerPage, filteredData.length)} of{' '}
                  {filteredData.length} entries
                </div>
                <div className="d-flex align-items-center">
                  <span className="me-2">Rows per page:</span>
                  <select
                    className="form-select form-select-sm"
                    style={{ width: '70px' }}
                    value={rowsPerPage}
                    onChange={(e) => setCurrentPage(1)}
                  >
                    <option>5</option>
                    <option>10</option>
                    <option>25</option>
                  </select>
                  <div className="btn-group ms-3">
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(prev => prev - 1)}
                    >
                      Previous
                    </button>
                    <button
                      className="btn btn-outline-secondary btn-sm"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage(prev => prev + 1)}
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default RegisteredLand;
