import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import '../assets/css/dashboard.css';

const Sidebar = ({ isOpen }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showSettingsSubmenu, setShowSettingsSubmenu] = useState(false);

  const isActive = (path) => location.pathname === path ? 'active' : '';

  const handleLogout = () => {
    
    localStorage.removeItem("token");
    navigate('/');
  };

  return (
    <nav id="sidebar" className={`sidebar ${!isOpen ? 'collapsed' : ''}`}>
      <div className="sidebar-header text-center">
        <img src="/images/location.png" alt="Logo" className="img-fluid logo" />
        <h3>Staff Panel</h3>
      </div>

      <ul className="list-unstyled components">
        <li className={isActive('/staff/staff-dashboard')}>
          <Link to="/staff/staff-dashboard">
            <i className="fas fa-tachometer-alt me-2"></i> Dashboard
          </Link>
        </li>
        <li className={isActive('/staff/register-land')}>
          <Link to="/staff/register-land">
            <i className="fas fa-map me-2"></i> Register Land
          </Link>
        </li>
        <li className={isActive('/staff/registered-land')}>
          <Link to="/staff/registered-land">
            <i className="fas fa-map-marked-alt me-2"></i> Registered Land
          </Link>
        </li>
        <li className={isActive('/staff/land-owner')}>
           <Link to="/staff/land-owner">
            <i className="fas fa-user-tie me-2"></i>  Land Owners
          </Link>
        </li>

        {/* Settings with submenu */}
        <li className={showSettingsSubmenu ? 'open' : ''}>
          <div
            className={`sidebar-link ${location.pathname.includes('/admin/settings') ? 'active' : ''}`}
            onClick={() => setShowSettingsSubmenu(!showSettingsSubmenu)}
            style={{ cursor: 'pointer', padding: '10px 22px', display: 'flex', alignItems: 'center' }}
          >
            <i className="fas fa-cog me-2"></i>
            <span style={{ flexGrow: 1 }}>Settings</span>
            <i className={`fas fa-chevron-${showSettingsSubmenu ? 'down' : 'right'}`}></i>
          </div>
          <ul className="submenu list-unstyled">
            <li className={isActive('#')}>
              <Link to="#">
                <i className="fas fa-key me-2"></i> Change Password
              </Link>
            </li>
          </ul>
        </li>

        {/* Logout */}
        <li>
          <div
            className="text-danger d-flex align-items-center"
            onClick={handleLogout}
            style={{ cursor: 'pointer', padding: '10px 25px' }}
          >
            <i className="fas fa-sign-out-alt me-2 text-danger"></i> Log Out
          </div>
        </li>
      </ul>
    </nav>
  );
};

export default Sidebar;
